from agatha.agatha import getOrTrainModel, predictFuture
from  agatha.AlphaVantageGateway import get_alpha_vantage_data